package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
class Group4 : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_group4)
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rf33lt3nk7pj))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rcfxc5pjqdu5))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rbscgwkxgs5j))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rzikuq8engsg))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rc0etlqdoon))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rd4yx68a33j))
	}
}