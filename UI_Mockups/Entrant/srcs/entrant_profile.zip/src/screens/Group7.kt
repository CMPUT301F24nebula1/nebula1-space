package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
class Group7 : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_group7)
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rr5gkj979d7o))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rsi0glmgliwp))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rc678rnt43nc))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rn17q4ww1ig))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rgrr5j0g3erp))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rq53128tzbld))
	}
}