package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
class Group6 : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_group6)
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r6kn06hh1ogy))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rkw35o47nyxs))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rej6vzc1itkb))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rom86p2dhj2))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rhd347l4f3y8))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rc1in3fc8dja))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rkt02xf0srt))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r0uq9labcv2s))
	}
}