package com.<your>.<application>
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
class Group5 : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_group5)
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r45yxp2y6c2f))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r0mvtmzfo1lt))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r7o0u60a1lp4))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.r0doku6pa109u))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rpu8u3lpl2ir))
		Glide.with(this).load("https://i.imgur.com/1tMFzp8.png").into(findViewById(R.id.rhdm9sjrayy))
	}
}